package com.employee.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.employee.Modal.entity.Branch;
import com.employee.Modal.entity.Department;
import com.employee.jdbc.BaseConnection;

public class DepartmentRepository extends BaseConnection{
	//dependecy inject
	public  DepartmentRepository(Connection connection) {
		this.connection=connection;
	}
	public List<Department> findAllDerpatment() {
		List<Department> deptList = new ArrayList<Department>();
		
		try {
			StringBuffer sqlQuery = new StringBuffer();
			sqlQuery.append("SELECT d.id AS departmentId , d.name AS departmentName ");
			sqlQuery.append("FROM department d  ");
			PreparedStatement ps = connection.prepareStatement(sqlQuery.toString());
			
			/**executing query to sqlserver and fetching the resulat set**/
			System.out.println("SQL QUERY "+ps.toString());
			ResultSet rs = ps.executeQuery();
			/**itrating the rows if present **/
			while(rs.next()) {
				Department department=new Department();
				department.setId(rs.getInt("departmentId"));
				department.setName(rs.getString("departmentName"));
				deptList.add(department);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return deptList;
		
	}

	
}
