package com.employee.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.employee.Modal.entity.Branch;
import com.employee.Modal.entity.Company;
import com.employee.jdbc.BaseConnection;

public class BranchRepository extends BaseConnection {
	//inject dependency 
	
	public BranchRepository(Connection connection) {
		this.connection=connection;
		// TODO Auto-generated constructor stub
	}
	public List<Branch> findAllBranch(){
		List<Branch> branchList = new ArrayList<Branch>();
		
		try {
			StringBuffer sqlQuery = new StringBuffer();
			sqlQuery.append("SELECT b.id AS branchId , b.name AS branchName ");
			sqlQuery.append("FROM branch b  ");
			PreparedStatement ps = connection.prepareStatement(sqlQuery.toString());
			
			/**executing query to sqlserver and fetching the resulat set**/
			System.out.println("SQL QUERY "+ps.toString());
			ResultSet rs = ps.executeQuery();
			/**itrating the rows if present **/
			while(rs.next()) {
				Branch branch=new Branch();
				branch.setId(rs.getInt("branchId"));
				branch.setName(rs.getString("branchName"));
				branchList.add(branch);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return branchList;
	}
}
