package com.employee.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.employee.Modal.entity.Company;
import com.employee.jdbc.BaseConnection;
public class CompanyRepository extends BaseConnection{
	public CompanyRepository(Connection connection) {
		this.connection = connection;
	}
	public List<Company> findAll(){
		List<Company> companyList = new ArrayList<Company>();
		
		try {
			StringBuffer sqlQuery = new StringBuffer();
			sqlQuery.append("SELECT c.id AS companyId,c.name AS companyName ");
			sqlQuery.append("FROM company c ");
			PreparedStatement ps = connection.prepareStatement(sqlQuery.toString());
			System.out.println("SQL QUERY "+ps.toString());
			/**executing query to sqlserver and fetching the resulat set**/
			ResultSet rs = ps.executeQuery();
			/**itrating the rows if present **/
			while(rs.next()) {
				Company company = new Company();
				company.setId(rs.getInt("companyId"));
				company.setName(rs.getString("companyName"));
				companyList.add(company);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return companyList;
	}
	
}
