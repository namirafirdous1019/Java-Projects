package com.employee.Repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import com.employee.Modal.entity.Employee;
import com.employee.jdbc.BaseConnection;

public class EmployeeRepository extends BaseConnection{
	
	public EmployeeRepository(Connection connection) {
		/**establishish  connection **/
		this.connection = connection;
	}
	
	
	public void save(Employee employee) {
		//3rd layer repository layer
		System.out.println("REPOSITORY START");
		
		
		try {
			
			StringBuffer sqlQuery = new StringBuffer();
			sqlQuery.append("INSERT INTO employee_data ");
			sqlQuery.append("(firstName,secondName,lastName,employeeCode, ");
			sqlQuery.append("gender,email,mobile_no, ");
			sqlQuery.append("company_Id,branch_Id,department_Id) ");
			sqlQuery.append("VALUES (?,?,?,?,?,?,?,?,?,?) ");
			
			PreparedStatement ps=connection.prepareStatement(sqlQuery.toString());
		
			ps.setString(1,employee.getFirstName());
			ps.setString(2,employee.getMiddlename());
			ps.setString(3, employee.getLastName());
			ps.setString(4,employee.getEmployeeCode());
			ps.setString(5, employee.getGender());
			ps.setString(6,employee.getEmail());
			ps.setInt(7, employee.getMobileNo());
			ps.setInt(8, employee.getCompanyId());
			ps.setInt(9, employee.getBranchId());
			ps.setInt(10, employee.getDepartmentId());
			
			System.out.println("SQL QUERY "+ps.toString());
			ps.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		System.out.println("REPOSITORY END");
	}
public List<Employee> getEmployeeData() {
	
		List<Employee> employeelist=new ArrayList();
		System.out.println("REPOSITORY fetch");
	
		try {
			
			StringBuffer sqlQuery = new StringBuffer();
			sqlQuery.append("SELECT c.name AS companyName, b.name AS branchName , d.name AS departmentName" );
			sqlQuery.append(" ");
			sqlQuery.append("FROM employee_data e"  );
			sqlQuery.append("INNER JOIN company c  ON e.company_id = c.id" );
			sqlQuery.append("INNER JOIN branch  b ON b.id=e.branch_id"  );    
			sqlQuery.append("INNER JOIN department  d ON d.id=e.department_id"  );
			sqlQuery.append("  ");
			
			//another Query
//			sqlQuery.append("SELECT*  ");
//			
//			sqlQuery.append(" Select * from employee_data");
			
			PreparedStatement ps=connection.prepareStatement(sqlQuery.toString());
			ResultSet rs = ps.executeQuery();
			System.out.println("SQL QUERY "+ps.toString());
			while(rs.next()) {
			Employee employee = new Employee();
		
			employee.setCompanyName(rs.getString("companyName"));
			employee.setBranchName(rs.getString("branchName"));
			employee.setBranchName(rs.getString("departmentName"));
//			
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		System.out.println("REPOSITORY fectch");
		
		return employeelist;
	}
}


