package com.employee.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.Modal.dto.EmployeeDTO;
import com.employee.Service.EmployeeService;


public class EmployeeSaveServlet extends HttpServlet{
	EmployeeService employeeService;
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		employeeService =new EmployeeService(); 
	}
@Override
protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	//first layer controller layer
	
	// TODO Auto-generated method stub
	String firstName=req.getParameter("firstName");
	String secondName=req.getParameter("secondName");
	String lastName=req.getParameter("lastName");
	String empCode=req.getParameter("empCode");
	String gender=req.getParameter("gender");
	String email=req.getParameter("email");
	String empcode=req.getParameter("empcode");
	String mobile_no=req.getParameter("mobile_no");
	int companyId=Integer.valueOf(req.getParameter("company"));
	int branchId=Integer.valueOf(req.getParameter("branch"));
	int departmentId=Integer.valueOf(req.getParameter("department"));
	String companyName=req.getParameter("comapnyName");
	String branchName=req.getParameter("branchName");
	String departmentName=req.getParameter("departmentName");
 	
	int mobile_no1=0;
	try {
		//convert integer to string
		  mobile_no1=Integer.parseInt(mobile_no);
	} catch (NumberFormatException e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	
	EmployeeDTO empdto=new EmployeeDTO();
	empdto.setFirstName(firstName);
	empdto.setMiddlename(secondName);
	empdto.setLastName(lastName);
	empdto.setEmployeeCode(empcode);
	empdto.setGender(gender);
	empdto.setEmail(email);
	empdto.setMobileNo(mobile_no1);
	empdto.setCompanyId(companyId);
	empdto.setBranchId(branchId);
	empdto.setDepartmentId(departmentId);
	empdto.setCompanyName(companyName);
	empdto.setBranchName(branchName);
	empdto.setDepartment(departmentName);
	
	
	//calling service method to send data in repository layer
	employeeService.saveEmployeeDetails(empdto);
	RequestDispatcher rd =req.getRequestDispatcher("/emp/register");
	rd.forward(req, resp);
	
	
}
}
