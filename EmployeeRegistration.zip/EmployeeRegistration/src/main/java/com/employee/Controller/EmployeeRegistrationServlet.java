package com.employee.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.Modal.dto.BranchDTO;
import com.employee.Modal.dto.CompanyDTO;
import com.employee.Modal.dto.DepartmentDTO;
import com.employee.Modal.dto.EmployeeDTO;
import com.employee.Repository.BranchRepository;
import com.employee.Repository.EmployeeRepository;
import com.employee.Service.BranchService;
import com.employee.Service.CompanyService;
import com.employee.Service.DepartmentService;
import com.employee.Service.EmployeeService;

public class EmployeeRegistrationServlet extends HttpServlet{
	private CompanyService companyService;
	private EmployeeService employeeService;
	private BranchService branchService ;
	private DepartmentService departmentService ;
	

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		
		companyService = new CompanyService();
		employeeService =new EmployeeService();
		branchService =new BranchService();
		departmentService =new DepartmentService();
		
	}
@Override

protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	List<EmployeeDTO> allemployee=employeeService.getAllEmployeeDTO();
	req.setAttribute("companyList", allemployee);
//
	List<CompanyDTO> allCompanyDTO = companyService.getAll();
	req.setAttribute("companyList", allCompanyDTO);
	
	List<BranchDTO> allBranchDTO=branchService.getAllBranch();
	req.setAttribute("branchList", allBranchDTO);
	
	List<DepartmentDTO> alldeptList=departmentService.getAllDepartment();
	req.setAttribute("deptList", alldeptList);
	
	
	RequestDispatcher rd =req.getRequestDispatcher("/pages/employee_registration.jsp");
	rd.include(req, resp);
}
}
