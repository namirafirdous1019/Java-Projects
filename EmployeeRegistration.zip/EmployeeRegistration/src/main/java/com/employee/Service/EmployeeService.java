package com.employee.Service;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import com.employee.Modal.entity.Employee;




import com.employee.Modal.dto.EmployeeDTO;
import com.employee.Repository.EmployeeRepository;
import com.employee.jdbc.ConnectionProvider;

public class EmployeeService {
	EmployeeRepository employeeRepository;

	
	
	public void saveEmployeeDetails(EmployeeDTO empdto) {
		//secondlayer service layer
		/**Establishing the connection object **/
		//connectiong to db
		Connection connection  =  ConnectionProvider.getConnection();
		/**Injecting connection object into the repository layer**/
		employeeRepository = new EmployeeRepository(connection);
		Employee employee=new Employee();
		employee.setFirstName(empdto.getFirstName());
		employee.setMiddlename(empdto.getMiddlename());
		employee.setLastName(empdto.getLastName());
		employee.setEmployeeCode(empdto.getEmployeeCode());
		employee.setEmail(empdto.getEmail());
		employee.setGender(empdto.getGender());
		employee.setMobileNo((empdto.getMobileNo()));
		employee.setCompanyId(empdto.getCompanyId());
		employee.setBranchId(empdto.getBranchId());
		employee.setDepartmentId(empdto.getDepartmentId());
		employee.setCompanyName(empdto.getCompanyName());
		employee.setBranchName(empdto.getBranchName());
		employee.setDepartmentName(empdto.getDepartment());
		
		employeeRepository.save(employee);
	}
	
	public List<EmployeeDTO> getAllEmployeeDTO() {
		//return dto list to return
		List<EmployeeDTO> employeedto=new ArrayList();
		//fetching data from repository
		List<Employee> employeelist=employeeRepository.getEmployeeData();
		
		employeelist.forEach(employee->{
			EmployeeDTO dto=new EmployeeDTO();
			
			//iterating 
			
		
 			dto.setFirstName(employee.getFirstName());
 			dto.setMiddlename(employee.getMiddlename());
 			dto.setLastName(employee.getLastName());
 			dto.setEmployeeCode(employee.getEmployeeCode());
 			dto.setEmail(employee.getEmail());
 			dto.setGender(employee.getGender());
 			dto.setMobileNo(employee.getMobileNo());
			
			dto.setCompanyId(employee.getCompanyId());
			dto.setCompanyName(employee.getCompanyName());
			dto.setBranchName(employee.getBranchName());
			dto.setDepartment(employee.getDepartmentName());
			
			
			
			
			employeedto.add(dto);
		});
		return employeedto;
	}
}
