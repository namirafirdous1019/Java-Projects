package com.employee.Service;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import com.employee.Modal.dto.BranchDTO;
import com.employee.Modal.dto.DepartmentDTO;
import com.employee.Modal.entity.Branch;
import com.employee.Modal.entity.Department;
import com.employee.Repository.BranchRepository;
import com.employee.Repository.DepartmentRepository;
import com.employee.jdbc.ConnectionProvider;

public class DepartmentService {
	public List<DepartmentDTO> getAllDepartment(){
		List<DepartmentDTO> deptlistdto = new ArrayList<DepartmentDTO>();
		
		/**Establishing connection **/
		Connection connection = ConnectionProvider.getConnection();
		
		/**injecting connection to repository layer **/
	
		DepartmentRepository departmentRepository=new DepartmentRepository(connection);
		
		
		/**fetching all companies from repository**/
		List<Department > alldept = departmentRepository.findAllDerpatment();
		
		/**converting entity to dto**/
		alldept.forEach(deptentity->{
			
			DepartmentDTO dto = new DepartmentDTO();
			dto.setId(deptentity.getId());
			dto.setName(deptentity.getName());
			deptlistdto.add(dto);
		});
		return deptlistdto;
	}
	
	

}
