package com.employee.Service;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import com.employee.Modal.dto.BranchDTO;
import com.employee.Modal.dto.CompanyDTO;
import com.employee.Modal.entity.Branch;
import com.employee.Modal.entity.Company;
import com.employee.Repository.BranchRepository;
import com.employee.Repository.CompanyRepository;
import com.employee.jdbc.ConnectionProvider;

public class BranchService {
	public List<BranchDTO> getAllBranch(){
		List<BranchDTO> barnchlistdto = new ArrayList<BranchDTO>();
		
		/**Establishing connection **/
		Connection connection = ConnectionProvider.getConnection();
		
		/**injecting connection to repository layer **/
	
		BranchRepository branchRepository=new BranchRepository(connection);
		
		
		/**fetching all companies from repository**/
		List<Branch> allbranch = branchRepository.findAllBranch();
		
		/**converting entity to dto**/
		allbranch.forEach(branchentity->{
			BranchDTO dto = new BranchDTO();
			dto.setId(branchentity.getId());
			dto.setName(branchentity.getName());
			barnchlistdto.add(dto);
		});
		return barnchlistdto;
	}
	

}
