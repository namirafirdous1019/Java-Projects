package com.employee.Service;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import com.employee.Modal.dto.CompanyDTO;
import com.employee.Modal.entity.Company;
import com.employee.Repository.CompanyRepository;
import com.employee.jdbc.ConnectionProvider;

public class CompanyService {
	

	public List<CompanyDTO> getAll(){
		List<CompanyDTO> list = new ArrayList<CompanyDTO>();
		
		/**Establishing connection **/
		Connection connection = ConnectionProvider.getConnection();
		
		/**injecting connection to repository layer **/
		CompanyRepository companyRepository = new CompanyRepository(connection);
		
		/**fetching all companies from repository**/
		List<Company> allCompanies = companyRepository.findAll();
		
		/**converting entity to dto**/
		allCompanies.forEach(entity->{
			CompanyDTO dto = new CompanyDTO();
			dto.setId(entity.getId());
			dto.setName(entity.getName());
			list.add(dto);
		});
		return list;
	}
	
}
