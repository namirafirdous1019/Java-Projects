package com.employee.jdbc;

import java.sql.Connection;

public class BaseConnection {
		
	protected Connection connection;
}
