package com.employee.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionProvider {

	public static Connection getConnection() {
		Connection connection=null;
		try {
			Class.forName("org.h2.Driver");
			connection=DriverManager.getConnection( "jdbc:h2:tcp://localhost/~/MyDemoDB","Admin", "Admin@123");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}
}
