package com.seroter.azure_basic_app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seroter.azure_basic_app.modal.dto.CountryDTO;
import com.seroter.azure_basic_app.modal.entity.Country;
import com.seroter.azure_basic_app.repository.CountryRepository;

@Service
public class CountryService {
	@Autowired
	CountryRepository countryRepository;

	public void saveCountry(CountryDTO countrydto) {
		// set data into entity
		Country country = new Country();
		country.setName(countrydto.getName());
		// repository save method
		countryRepository.save(country);
	}

	public List<CountryDTO> getAll() {

		List<CountryDTO> countrydto = new ArrayList();
		// find all method save in the list
		List<Country> list = countryRepository.findAll();
		// now list will iterate and each elemt will be stored in the dto
		list.forEach(country -> {
			CountryDTO dto = new CountryDTO();
			// set data into dto from entity
			dto.setId(country.getId());
			dto.setName(country.getName());
			// stored dto object into dto list
			countrydto.add(dto);
		});

		return countrydto;

	}

	public List<CountryDTO> getById(int id) {
		List<CountryDTO> countrydto = new ArrayList();
		// optional is just like a container
		// if value not present in that container it will return empty
		Optional<Country> list = countryRepository.findById(id);
		// if value is present in it will be get in the country object
		if (list.isPresent()) {
			Country country = list.get();

			CountryDTO dto = new CountryDTO();
			// element will be stored in the dto
			dto.setId(country.getId());
			dto.setName(country.getName());
			countrydto.add(dto);
		}

		return countrydto;

	}

}
