package com.seroter.azure_basic_app.controller;

import java.util.List;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seroter.azure_basic_app.modal.dto.CountryDTO;
import com.seroter.azure_basic_app.service.CountryService;

@RestController
@RequestMapping(value = "/countryapi")
public class CountryController {

	@Autowired
	private CountryService countryService;
	@PostMapping(value = "/save")
	// save data
	public ResponseEntity<String> save(@RequestBody CountryDTO countrydto) {
		//service method called
		countryService.saveCountry(countrydto);
		return new ResponseEntity<String>(countrydto.getName() + " Saved succuessfully", HttpStatus.OK);
	}
	@GetMapping(value = "/getall")
	//Response entity return a http status
	public ResponseEntity<List<CountryDTO>> getAllCountry() {
		//httpstatus ok means data sent succesfully
		return new ResponseEntity<>(countryService.getAll(), HttpStatus.OK);
	}
//    @GetMapping(value="/get/{id}/{cityid}")
//    	public List <CountryDTO> getId(@PathVariable("id") int id,@PathVariable("cityid") int cityid) {
//    		return countryService.getById(id);
//    	}
	@GetMapping(value = "/get/{id}")
	public ResponseEntity<List<CountryDTO>> getId(@PathVariable("id") int id) {
		return new ResponseEntity<>(countryService.getById(id),HttpStatus.OK);
	}

}
