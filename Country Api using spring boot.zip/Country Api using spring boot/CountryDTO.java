package com.seroter.azure_basic_app.modal.dto;

import java.util.List;

public class CountryDTO {
	private int id;
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "CountryDTO [id=" + id + ", name=" + name + "]";
	}
	public void addAttribute(String string, List<CountryDTO> all) {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
